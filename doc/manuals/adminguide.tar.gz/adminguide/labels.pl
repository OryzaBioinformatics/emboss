# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate labels original text with physical files.


$key = q/sec:FreeBSD/;
$external_labels{$key} = "$URL/" . q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:finetune/;
$external_labels{$key} = "$URL/" . q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:fasta/;
$external_labels{$key} = "$URL/" . q|node42.html|; 
$noresave{$key} = "$nosave";

1;

