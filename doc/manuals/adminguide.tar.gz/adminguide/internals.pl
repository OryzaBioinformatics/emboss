# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate internals original text with physical files.


$key = q/sec:FreeBSD/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:finetune/;
$ref_files{$key} = "$dir".q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:fasta/;
$ref_files{$key} = "$dir".q|node42.html|; 
$noresave{$key} = "$nosave";

1;

