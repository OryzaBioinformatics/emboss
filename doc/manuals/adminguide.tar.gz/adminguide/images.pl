# LaTeX2HTML 97.1 (release) (July 13th, 1997)
# Associate images original text with physical files.


1;

